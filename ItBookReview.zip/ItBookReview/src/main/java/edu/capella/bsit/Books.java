package edu.capella.bsit;

import java.util.List;

public class Books {
    private String title;
    private List<String> authors;
    private String ISBN;
    private int publicationYear;
    private String version;

    // Constructor
    public Books(String title, List<String> authors, String ISBN, int publicationYear, String version) {
        this.title = title;
        this.authors = authors;
        this.ISBN = ISBN;
        this.publicationYear = publicationYear;
        this.version = version;
    }

    // Getters and setters
    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public List<String> getAuthors() {
        return authors;
    }

    public void setAuthors(List<String> authors) {
        this.authors = authors;
    }

    public String getIsbn() {
        return ISBN;
    }

    public void setIsbn(String ISBN) {
        this.ISBN = ISBN;
    }

    public int getPublicationYear() {
        return publicationYear;
    }

    public void setPublicationYear(int publicationYear) {
        this.publicationYear = publicationYear;
    }

    public String getVersion() {
        return version;
    }

    public void setVersion(String version) {
        this.version = version;
    }
}