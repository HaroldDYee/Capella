package edu.capella.bsit;

public class Users {
    private String userName;
    private String realName;
    private String email;
    private int numOfReviews;
    private int avgRevRating;

    // Constructor
    public Users(String userName, String realName, String email, int numOfReviews, int avgRevRating) {
        this.userName = userName;
        this.realName = realName;
        this.email = email;
        this.numOfReviews = numOfReviews;
        this.avgRevRating = avgRevRating;
    }

    // Getters and setters
    public String getUsername() {
        return userName;
    }

    public void setUsername(String userName) {
        this.userName = userName;
    }

    public String getRealname() {
        return realName;
    }

    public void setRealname(String realName) {
        this.realName = realName;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public int getNumOfReviews() {
        return numOfReviews;
    }

    public void setNumOfReviews(int numOfReviews) {
        this.numOfReviews = numOfReviews;
    }

    public double getAvgRevRating() {
        return avgRevRating;
    }

    public void setAvgRevRating(int avgRevRating) {
        this.avgRevRating = avgRevRating;
    }
}
