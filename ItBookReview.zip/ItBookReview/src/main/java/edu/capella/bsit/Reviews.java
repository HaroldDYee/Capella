package edu.capella.bsit;

public class Reviews {
    private String bookISBN;
    private String reviewUser;
    private String reviewText;
    private int reviewBookRating;
    private int reviewUserRating;

    // Constructor
    public Reviews(String bookISBN, String reviewUser, String reviewText, int reviewBookRating, int reviewUserRating) {
        this.bookISBN = bookISBN;
        this.reviewUser = reviewUser;
        this.reviewText = reviewText;
        this.reviewBookRating = reviewBookRating;
        this.reviewUserRating = reviewUserRating;
    }

    // Getters and setters
    public String getBookISBN() {
        return bookISBN;
    }

    public void setBookISBN(String bookISBN) {
        this.bookISBN = bookISBN;
    }

    public String getReviewUser() {
        return reviewUser;
    }

    public void setReviewUser(String reviewUser) {
        this.reviewUser = reviewUser;
    }

    public String getReviewText() {
        return reviewText;
    }

    public void setReviewText(String reviewText) {
        this.reviewText = reviewText;
    }

    public int getReviewBookRating() {
        return reviewBookRating;
    }

    public void setReviewBookRating(int reviewBookRating) {
        this.reviewBookRating = reviewBookRating;
    }
    
    public int getReviewUserRating() {
        return reviewUserRating;
    }

    public void setReviewUserRating(int reviewUserRating) {
        this.reviewUserRating = reviewUserRating;
    }
}
