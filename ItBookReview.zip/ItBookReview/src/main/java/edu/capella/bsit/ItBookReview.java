package edu.capella.bsit;

import com.mongodb.BasicDBObject;
import com.mongodb.MongoClient;
import com.mongodb.MongoClientURI;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoCursor;
import com.mongodb.client.MongoDatabase;
import static com.mongodb.client.model.Projections.fields;
import static com.mongodb.client.model.Projections.include;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.bson.Document;

public class ItBookReview {

    // declares collections to be used in methods
    private static MongoCollection<Document> bookCollection;
    private static MongoCollection<Document> reviewCollection;
    private static MongoDatabase mongoDB;

    public static void main(String[] args) {
        Logger mongoLogger = Logger.getLogger("org.mongodb.driver");
        mongoLogger.setLevel(Level.WARNING);
        
         // Declare empty URI string to avoid scope problems
        String mongoURI = "";

        // Retrieves user information
        Scanner input = new Scanner(System.in);
        System.out.print("Please enter your Username: ");
        String user = input.nextLine();
        System.out.print("Please enter your Password: ");
        String password = input.nextLine();
        
        // Need to URLEncode password due to "special" character
        // URLEncoder.encode() can throw an exception (UnsupportedEncodingException)
        // Note need to provide database name at end. Users are in review database
        try {
            mongoURI = "mongodb://" + user + ":" +
            URLEncoder.encode(password,"UTF-8") + "@localhost:27017/IT_Book_Review";
        }
        catch (UnsupportedEncodingException ex) {
            Logger.getLogger(ItBookReview.class.getName()).log(Level.SEVERE, null, ex);
        }

        String database = "IT_Book_Review";
        String books = "books";
        String reviews = "reviews";

        MongoClientURI mongoConnURI = new MongoClientURI(mongoURI);
        MongoClient mongoClient = new MongoClient(mongoConnURI);
        mongoDB = mongoClient.getDatabase(database);
        bookCollection = mongoDB.getCollection(books);
        reviewCollection = mongoDB.getCollection(reviews);

        // Retrieves users desired title
        System.out.print("Enter the desired title: ");
        String wantBook = input.nextLine();

        // Calls the method to find book by title
        List<Books> foundBooks = searchBooksByTitle(wantBook);

        // Checks if a book was found
        if (foundBooks.isEmpty()) {
            System.out.println("Could not find a book with that title.");
        } else {
            // Displays book information to the user
            System.out.println("Books containing " + wantBook + " :");
            for (int i = 0; i < foundBooks.size(); i++) {
                System.out.println((i + 1) + ". " + foundBooks.get(i).getTitle()+ 
             " (ISBN: " + foundBooks.get(i).getIsbn() + ", Version: " + foundBooks.get(i).getVersion() +
             ", Publication Year: " + foundBooks.get(i).getPublicationYear() + ")");
            }

            System.out.print("Select the number of the book: ");
            int selectedTitleIndex = input.nextInt();
            // Clears the line input from the buffer
            input.nextLine();

            if (selectedTitleIndex > 0 && selectedTitleIndex <= foundBooks.size()) {
                Books selectedBook = foundBooks.get(selectedTitleIndex - 1);
                System.out.println("Fetching further information for: " + selectedBook.getTitle());

                // Retrieve further information about the selected book and its reviews
                retrieveBookInfo(selectedBook);
                System.out.println("Do you want to see information about a specific review user? (yes/no)");
                String choice = input.nextLine();
                if ("yes".equalsIgnoreCase(choice)) {
                    System.out.print("Enter the username of the review user: ");
                    String reviewUsername = input.nextLine();
                    retrieveReviewUserInfo(reviewUsername);
                }
            } else {
                System.out.println("Invalid selection.");
            }
        }
        // Close the mongoDB connections
        mongoClient.close();
    }


    private static List<Books> searchBooksByTitle(String title) {
        BasicDBObject findBook = new BasicDBObject("title", new BasicDBObject("$regex", title).append("$options", "i"));
        MongoCursor<Document> cursor = bookCollection.find(findBook).projection(fields(include("title", "authors", "ISBN", "publicationYear", "version"))).iterator();

        List<Books> books = new ArrayList<>();
        while (cursor.hasNext()) {
            Document bookJSON = cursor.next();
            Books book = new Books(
                    bookJSON.getString("title"),
                    (List<String>) bookJSON.get("authors"),
                    bookJSON.getString("ISBN"),
                    bookJSON.getInteger("publicationYear"),
                    bookJSON.getString("version")
            );
            books.add(book);
        }
        return books;
    }

    private static void retrieveBookInfo(Books book) {
        System.out.println("Title: " + book.getTitle());
        System.out.print("Authors: ");
        List<String> authors = book.getAuthors();
        for (int i = 0; i < authors.size(); i++) {
            System.out.print(authors.get(i));
            if (i < authors.size() - 1) {
                System.out.print(", ");
            }
        }
        System.out.println();
        System.out.println("ISBN: " + book.getIsbn());
        System.out.println("Publication Year: " + book.getPublicationYear());
        System.out.println("Version: " + book.getVersion());

        String isbn = book.getIsbn();

        BasicDBObject reviewQuery = new BasicDBObject("bookISBN", isbn);
        MongoCursor<Document> reviewsCursor = reviewCollection.find(reviewQuery).iterator();

        if (reviewsCursor.hasNext()) {
            System.out.println("Reviews:");
            while (reviewsCursor.hasNext()) {
                Document review = reviewsCursor.next();
                System.out.println("Book Title: " + book.getTitle());
                System.out.println("Reviewer Name: " + review.getString("review_user"));
                System.out.println("Reviewer Rating: " + review.getInteger("review_user_rating"));
                System.out.println("Book Rating: " + review.getInteger("review_book_rating"));
                System.out.println("Review: " + review.getString("review"));
                System.out.println();
            }
        } else {
            System.out.println("No reviews available for this book.");
        }
    }
    
    private static void retrieveReviewUserInfo(String username) {
        BasicDBObject query = new BasicDBObject("username", username);
        Document userDoc = mongoDB.getCollection("users").find(query).first();

        if (userDoc != null) {
            Users user = new Users(
                    userDoc.getString("username"),
                    userDoc.getString("realname"),
                    userDoc.getString("email"),
                    userDoc.getInteger("num_of_reviews"),
                    userDoc.getInteger("avg_rev_rating")
            );

            System.out.println("User Information:");
            System.out.println("Username: " + user.getUsername());
            System.out.println("Number of Reviews: " + user.getNumOfReviews());
            System.out.println("Average Review Rating: " + user.getAvgRevRating());
        } else {
            System.out.println("User with username " + username + " not found.");
        }
    }
}