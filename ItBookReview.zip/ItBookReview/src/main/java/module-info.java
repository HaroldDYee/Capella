module ItBookReview {
    requires java.logging;
    requires mongo.java.driver;
    exports edu.capella.bsit;
}
